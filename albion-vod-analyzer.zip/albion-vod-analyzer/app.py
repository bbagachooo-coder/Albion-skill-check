"""
Albion VOD Analyzer — Gradio Web App
=====================================
YouTube URL 또는 로컬 파일에서 알비온 스킬 사용을 자동 감지합니다.

로컬 실행:
    pip install -r requirements.txt
    python app.py

Hugging Face Spaces 배포:
    GitHub에 푸시 후 HF Space에 연결
"""

import os
import json
import tempfile
import shutil
import time
from datetime import datetime
from pathlib import Path

import cv2
import numpy as np
import gradio as gr
import yt_dlp


# ─────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────
SKILLS = ['A', 'Q', 'W', 'E', 'R', 'D', 'F', '1', '2']
TEMP_DIR = Path(tempfile.gettempdir()) / 'albion_vod'
TEMP_DIR.mkdir(exist_ok=True)


# ─────────────────────────────────────────
# UTILITIES
# ─────────────────────────────────────────
def fmt_time(s):
    """초 → HH:MM:SS"""
    s = int(s or 0)
    h, m, ss = s // 3600, (s % 3600) // 60, s % 60
    return f"{h:02d}:{m:02d}:{ss:02d}"


# ─────────────────────────────────────────
# YOUTUBE DOWNLOADER
# ─────────────────────────────────────────
def download_youtube(url, progress=gr.Progress()):
    """YouTube에서 영상 다운로드, 진행률 표시"""
    if not url or not url.strip():
        raise gr.Error("YouTube URL을 입력하세요")

    progress(0, desc="YouTube 영상 정보 확인 중...")

    state = {'percent': 0.0, 'status': '준비 중'}

    def hook(d):
        if d['status'] == 'downloading':
            try:
                total = d.get('total_bytes') or d.get('total_bytes_estimate', 0)
                downloaded = d.get('downloaded_bytes', 0)
                if total > 0:
                    state['percent'] = downloaded / total
                    speed = d.get('speed', 0) or 0
                    speed_mb = speed / 1024 / 1024 if speed else 0
                    state['status'] = f"다운로드 중: {state['percent']*100:.1f}% ({speed_mb:.1f} MB/s)"
            except Exception:
                pass

    # 임시 폴더 비우기 (이전 다운로드 정리)
    for old in TEMP_DIR.glob('*.mp4'):
        try:
            old.unlink()
        except Exception:
            pass

    out_template = str(TEMP_DIR / 'video_%(epoch)s.%(ext)s')
    ydl_opts = {
        'format': 'best[ext=mp4][height<=720]/best[height<=720]/best',
        'outtmpl': out_template,
        'progress_hooks': [hook],
        'quiet': True,
        'no_warnings': True,
        'restrictfilenames': True,
        'noplaylist': True,
    }

    final_path = None
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            title = info.get('title', 'video')
            duration = info.get('duration', 0)

            progress(0.05, desc=f"다운로드 시작: {title[:40]}")

            ydl.download([url])

            # 다운로드된 파일 찾기
            filename = ydl.prepare_filename(info)
            if os.path.exists(filename):
                final_path = filename
            else:
                # 확장자 변경 가능성
                base = os.path.splitext(filename)[0]
                for ext in ('.mp4', '.webm', '.mkv'):
                    if os.path.exists(base + ext):
                        final_path = base + ext
                        break

            # 최후의 보루: TEMP_DIR에서 가장 최근 mp4
            if not final_path:
                mp4s = sorted(TEMP_DIR.glob('*.mp4'),
                              key=lambda p: p.stat().st_mtime, reverse=True)
                if mp4s:
                    final_path = str(mp4s[0])

    except Exception as e:
        raise gr.Error(f"다운로드 실패: {str(e)[:200]}")

    if not final_path or not os.path.exists(final_path):
        raise gr.Error("다운로드된 파일을 찾을 수 없습니다")

    progress(1.0, desc="다운로드 완료")
    return final_path


# ─────────────────────────────────────────
# VIDEO ANALYSIS ENGINE
# ─────────────────────────────────────────
def analyze_video(video_path, selected_skills, sensitivity, auto_locate, progress):
    """
    영상에서 알비온 스킬 사용을 감지.

    핵심 아이디어:
    - 스킬 사용 가능 상태 = 컬러풀한 아이콘 (높은 HSV 채도)
    - 쿨타임 중 = 회색 숫자 (낮은 채도)
    - 채도가 급격히 떨어지는 순간 = 스킬 사용
    """
    if not video_path or not os.path.exists(video_path):
        raise gr.Error("영상 파일을 찾을 수 없습니다")

    if not selected_skills:
        raise gr.Error("최소 1개 이상의 스킬을 선택하세요")

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        raise gr.Error(f"영상을 열 수 없습니다")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    duration = total_frames / fps
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

    progress(0.0, desc=f"영상 정보: {width}x{height}, {fmt_time(duration)}")

    # ── 스킬바 위치 결정 ──
    if auto_locate:
        bar_y_ratio, bar_h_ratio = locate_skill_bar(cap, height, width)
    else:
        bar_y_ratio, bar_h_ratio = 0.87, 0.10

    bar_y = int(height * bar_y_ratio)
    bar_h = int(height * bar_h_ratio)

    # 9개 슬롯의 X 범위 (중앙 56% 영역)
    slot_x_start = int(width * 0.22)
    slot_x_end = int(width * 0.78)
    slot_w = (slot_x_end - slot_x_start) / 9
    slot_ranges = [
        (int(slot_x_start + i * slot_w), int(slot_x_start + (i + 1) * slot_w))
        for i in range(9)
    ]

    # ── 메인 분석 루프 ──
    sample_interval = max(1, int(fps * 0.25))  # 0.25초마다
    prev_slot_saturations = None
    last_event_time = -3.0
    cooldown = 1.0

    events = []
    selected_set = set(selected_skills)

    cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
    frame_idx = 0

    while True:
        ret = cap.grab()
        if not ret:
            break

        if frame_idx % sample_interval == 0:
            ret, frame = cap.retrieve()
            if not ret:
                frame_idx += 1
                continue

            t = frame_idx / fps
            pct = frame_idx / total_frames if total_frames > 0 else 0

            # UI 업데이트 (매 40프레임마다)
            if frame_idx % (sample_interval * 4) == 0:
                progress(pct,
                         desc=f"분석 중 {fmt_time(t)}/{fmt_time(duration)} — {len(events)}개 감지")

            # 스킬바 영역 → HSV 변환
            bar_region = frame[bar_y:bar_y + bar_h, :, :]
            if bar_region.size == 0:
                frame_idx += 1
                continue

            hsv = cv2.cvtColor(bar_region, cv2.COLOR_BGR2HSV)

            # 각 슬롯의 평균 채도
            slot_saturations = []
            for sx, ex in slot_ranges:
                slot_hsv = hsv[:, sx:ex, :]
                if slot_hsv.size == 0:
                    slot_saturations.append(0)
                    continue
                sat_mean = float(np.mean(slot_hsv[:, :, 1]))
                slot_saturations.append(sat_mean)

            # 이전 프레임과 비교
            if prev_slot_saturations is not None:
                for i, (cur_sat, prev_sat) in enumerate(zip(slot_saturations, prev_slot_saturations)):
                    skill = SKILLS[i]
                    if skill not in selected_set:
                        continue
                    sat_drop = prev_sat - cur_sat
                    if sat_drop > sensitivity and t - last_event_time > cooldown:
                        events.append({
                            'skill': skill,
                            'time_raw': round(t, 2),
                            'time_str': fmt_time(t),
                            'eval': None,
                            'note': '',
                            'sat_drop': round(sat_drop, 1),
                            'created_at': datetime.now().isoformat()
                        })
                        last_event_time = t

            prev_slot_saturations = slot_saturations

        frame_idx += 1

    cap.release()
    progress(1.0, desc=f"분석 완료: {len(events)}개 감지")
    return events


def locate_skill_bar(cap, height, width):
    """영상 하단에서 가장 채도 높은 가로 줄 찾기 = 스킬바 위치"""
    # 2초 시점 사용 (인트로 회피)
    cap.set(cv2.CAP_PROP_POS_MSEC, 2000)
    ret, frame = cap.read()
    if not ret:
        return 0.87, 0.10

    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
    start_y = int(height * 0.65)

    sat_per_row = []
    for y in range(start_y, height - 5, 2):
        row_hsv = hsv[y:y+1, int(width*0.2):int(width*0.8), :]
        sat_per_row.append((y, float(np.mean(row_hsv[:, :, 1]))))

    if not sat_per_row:
        return 0.87, 0.10

    best_y, _ = max(sat_per_row, key=lambda x: x[1])
    bar_h_px = int(height * 0.10)
    bar_top = max(0, best_y - bar_h_px // 2 - 5)

    return bar_top / height, bar_h_px / height


# ─────────────────────────────────────────
# CLIP EXTRACTION
# ─────────────────────────────────────────
def extract_clip(video_path, time_raw, before=5, after=3):
    """특정 시점의 -5초 ~ +3초 클립을 임시 mp4로 추출"""
    if not video_path or not os.path.exists(video_path):
        return None

    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return None

    fps = cap.get(cv2.CAP_PROP_FPS) or 30
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    start_time = max(0, time_raw - before)
    end_time = min(total_frames / fps, time_raw + after)

    start_frame = int(start_time * fps)
    end_frame = int(end_time * fps)

    clip_path = TEMP_DIR / f"clip_{int(time_raw*100)}.mp4"

    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(str(clip_path), fourcc, fps, (width, height))

    cap.set(cv2.CAP_PROP_POS_FRAMES, start_frame)
    for _ in range(end_frame - start_frame):
        ret, frame = cap.read()
        if not ret:
            break
        out.write(frame)

    cap.release()
    out.release()
    return str(clip_path)


# ─────────────────────────────────────────
# APP STATE MANAGEMENT (events stored in gr.State)
# ─────────────────────────────────────────
def events_to_dataframe(events, filter_val='all'):
    """이벤트 목록 → DataFrame 형태"""
    if not events:
        return []

    filtered = events
    if filter_val == 'good':
        filtered = [e for e in events if e['eval'] is True]
    elif filter_val == 'bad':
        filtered = [e for e in events if e['eval'] is False]
    elif filter_val == 'neutral':
        filtered = [e for e in events if e['eval'] is None]

    return [
        [
            '✅' if e['eval'] is True else '❌' if e['eval'] is False else '⬜',
            e['skill'],
            e['time_str'],
            e.get('note', '')[:50] if e.get('note') else '',
            round(e.get('sat_drop', 0), 1),
            i,  # 원본 인덱스
        ]
        for i, e in enumerate(events)
        if (filter_val == 'all'
            or (filter_val == 'good' and e['eval'] is True)
            or (filter_val == 'bad' and e['eval'] is False)
            or (filter_val == 'neutral' and e['eval'] is None))
    ]


def get_stats_text(events):
    """통계 텍스트 생성"""
    if not events:
        return "**아직 분석 결과가 없습니다**"

    total = len(events)
    good = sum(1 for e in events if e['eval'] is True)
    bad = sum(1 for e in events if e['eval'] is False)
    neutral = total - good - bad
    pct = (good / total * 100) if total else 0

    # 스킬별 통계
    by_skill = {}
    for e in events:
        s = e['skill']
        if s not in by_skill:
            by_skill[s] = {'t': 0, 'g': 0, 'b': 0}
        by_skill[s]['t'] += 1
        if e['eval'] is True:
            by_skill[s]['g'] += 1
        elif e['eval'] is False:
            by_skill[s]['b'] += 1

    lines = [
        f"### 📊 통계",
        f"- **총 감지**: {total}개",
        f"- ✅ 잘씀: {good} / ❌ 못씀: {bad} / ⬜ 미판정: {neutral}",
        f"- **판정 정확도**: {pct:.1f}%",
        "",
        "### 스킬별",
    ]
    for sk in SKILLS:
        if sk in by_skill:
            v = by_skill[sk]
            sk_pct = (v['g'] / v['t'] * 100) if v['t'] else 0
            lines.append(f"- **{sk}**: {v['t']}회 (✅{v['g']} ❌{v['b']}) — {sk_pct:.0f}%")

    return "\n".join(lines)


# ─────────────────────────────────────────
# GRADIO HANDLERS
# ─────────────────────────────────────────
def handle_youtube_load(url, progress=gr.Progress()):
    """YouTube URL → 영상 다운로드"""
    video_path = download_youtube(url, progress)
    return (
        video_path,                                # video_path_state
        gr.update(value=video_path, visible=True), # video_preview
        f"✅ 다운로드 완료: {os.path.basename(video_path)}",
    )


def handle_file_upload(file_obj):
    """파일 업로드 처리"""
    if file_obj is None:
        return None, gr.update(visible=False), "파일 미선택"

    video_path = file_obj  # gr.File이 file path 반환
    return (
        video_path,
        gr.update(value=video_path, visible=True),
        f"✅ 파일 로드: {os.path.basename(video_path)}",
    )


def handle_analyze(video_path, selected_skills, sensitivity, auto_locate,
                   existing_events, progress=gr.Progress()):
    """분석 실행"""
    if not video_path:
        raise gr.Error("영상을 먼저 로드하세요")

    events = analyze_video(video_path, selected_skills, sensitivity, auto_locate, progress)

    # 기존 이벤트와 합치지 않고 새로 시작
    df = events_to_dataframe(events, 'all')
    stats = get_stats_text(events)

    return (
        events,                          # events_state
        df,                              # log_table
        stats,                           # stats_md
        f"✅ 분석 완료: {len(events)}개 감지"  # status
    )


def handle_filter(events, filter_val):
    df = events_to_dataframe(events or [], filter_val)
    return df


def handle_set_eval(events, selected_row_idx, eval_val):
    """판정 설정 (True=잘씀, False=못씀, None=미판정)"""
    if events is None or selected_row_idx is None:
        return events, events_to_dataframe(events or [], 'all'), get_stats_text(events or [])

    try:
        idx = int(selected_row_idx)
        if 0 <= idx < len(events):
            if eval_val is None:
                # 명시적 미판정 설정
                events[idx]['eval'] = None
            else:
                current = events[idx]['eval']
                events[idx]['eval'] = None if current == eval_val else eval_val
    except (ValueError, TypeError):
        pass

    df = events_to_dataframe(events, 'all')
    stats = get_stats_text(events)
    return events, df, stats


def handle_update_note(events, selected_row_idx, note_text):
    """메모 업데이트"""
    if events is None or selected_row_idx is None:
        return events, events_to_dataframe(events or [], 'all')

    try:
        idx = int(selected_row_idx)
        if 0 <= idx < len(events):
            events[idx]['note'] = note_text or ''
    except (ValueError, TypeError):
        pass

    df = events_to_dataframe(events, 'all')
    return events, df


def handle_play_clip(video_path, events, selected_row_idx):
    """선택한 로그의 클립 추출 + 정보 표시"""
    if not video_path or events is None or selected_row_idx is None:
        return None, "로그를 선택하세요", "", "⬜ 미판정"

    try:
        idx = int(selected_row_idx)
        if not (0 <= idx < len(events)):
            return None, "유효하지 않은 로그", "", "⬜ 미판정"
    except (ValueError, TypeError):
        return None, "로그를 선택하세요", "", "⬜ 미판정"

    event = events[idx]
    clip_path = extract_clip(video_path, event['time_raw'])

    if not clip_path:
        return None, "클립 추출 실패", "", "⬜ 미판정"

    info = f"### {event['skill']} 스킬 @ {event['time_str']}\n"
    info += f"채도 변화: {event.get('sat_drop', 0):.1f}"

    eval_text = '✅ 잘씀' if event['eval'] is True else '❌ 못씀' if event['eval'] is False else '⬜ 미판정'

    return clip_path, info, event.get('note', ''), eval_text


def handle_row_select(evt: gr.SelectData):
    """테이블 행 선택 이벤트"""
    if evt is None or evt.index is None:
        return None
    # evt.index = [row_idx, col_idx]
    row_idx = evt.index[0] if isinstance(evt.index, list) else evt.index
    return row_idx


def handle_export_csv(events):
    if not events:
        raise gr.Error("내보낼 로그가 없습니다")

    path = TEMP_DIR / f"albion_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"
    with open(path, 'w', encoding='utf-8-sig') as f:
        f.write('스킬,시간,판정,메모,채도변화,기록일시\n')
        for e in events:
            eval_txt = '잘씀' if e['eval'] is True else '못씀' if e['eval'] is False else '미판정'
            note = (e.get('note', '') or '').replace(',', '，').replace('\n', ' ')
            f.write(f"{e['skill']},{e['time_str']},{eval_txt},{note},"
                   f"{e.get('sat_drop', 0)},{e.get('created_at', '')}\n")
    return str(path)


def handle_export_json(events, video_path):
    if not events:
        raise gr.Error("내보낼 로그가 없습니다")

    path = TEMP_DIR / f"albion_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    data = {
        'version': 1,
        'video_filename': os.path.basename(video_path) if video_path else '',
        'events': events,
        'exported_at': datetime.now().isoformat()
    }
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    return str(path)


def handle_import_json(file_obj, existing_events):
    if file_obj is None:
        return existing_events or [], events_to_dataframe(existing_events or [], 'all'), \
               get_stats_text(existing_events or []), "파일을 선택하세요"

    try:
        with open(file_obj, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if 'events' not in data or not isinstance(data['events'], list):
            raise gr.Error("올바른 형식이 아닙니다")

        merged = (existing_events or []) + data['events']
        df = events_to_dataframe(merged, 'all')
        stats = get_stats_text(merged)
        return merged, df, stats, f"✅ {len(data['events'])}개 로그 불러옴"
    except Exception as e:
        raise gr.Error(f"불러오기 실패: {str(e)[:100]}")


def handle_clear_logs():
    return [], [], get_stats_text([]), "로그 초기화됨"


# ─────────────────────────────────────────
# UI - CUSTOM CSS
# ─────────────────────────────────────────
CUSTOM_CSS = """
.gradio-container {
    max-width: 1400px !important;
    background: #0a0c10 !important;
}
.gr-box, .gr-form, .gr-input, .gr-button {
    border-color: #2a2f3d !important;
}
h1, h2, h3 {
    color: #e8c96d !important;
}
.gr-button-primary {
    background: linear-gradient(135deg, #c9a84c, #a07830) !important;
    color: #1a1200 !important;
    font-weight: 700 !important;
}
.status-bar {
    padding: 8px 14px;
    background: #181c24;
    border-left: 3px solid #c9a84c;
    border-radius: 6px;
    font-size: 13px;
}
"""


# ─────────────────────────────────────────
# UI - BUILD
# ─────────────────────────────────────────
def build_ui():
    with gr.Blocks(
        title="⚔️ Albion VOD Analyzer",
        theme=gr.themes.Base(
            primary_hue=gr.themes.colors.amber,
            neutral_hue=gr.themes.colors.slate,
        ).set(
            body_background_fill="#0a0c10",
            block_background_fill="#111318",
            block_border_color="#2a2f3d",
            input_background_fill="#181c24",
        ),
        css=CUSTOM_CSS,
    ) as app:

        # ── STATE ──
        events_state = gr.State([])
        video_path_state = gr.State(None)
        selected_row_state = gr.State(None)

        gr.Markdown("""
        # ⚔️ Albion VOD Analyzer
        **알비온 온라인 PvP 영상에서 스킬 사용을 자동으로 감지 · 분석합니다**
        """)

        # ════════════════════════════════════════
        # STEP 1: 영상 로드
        # ════════════════════════════════════════
        with gr.Tab("1️⃣ 영상 로드 & 분석"):
            with gr.Row():
                with gr.Column(scale=1):
                    gr.Markdown("### 📺 YouTube URL")
                    yt_url = gr.Textbox(
                        label="YouTube 링크",
                        placeholder="https://youtu.be/xxxxx",
                        lines=1,
                    )
                    yt_load_btn = gr.Button("⬇ YouTube 다운로드", variant="primary")

                with gr.Column(scale=1):
                    gr.Markdown("### 📁 로컬 파일")
                    file_upload = gr.File(
                        label="영상 파일 (mp4, webm, mov)",
                        file_types=["video"],
                        type="filepath"
                    )

            status_display = gr.Markdown("**대기 중**", elem_classes=["status-bar"])

            video_preview = gr.Video(
                label="로드된 영상",
                visible=False,
                interactive=False
            )

            gr.Markdown("### ⚙️ 분석 설정")

            with gr.Row():
                with gr.Column(scale=2):
                    skills_input = gr.CheckboxGroup(
                        choices=SKILLS,
                        value=SKILLS,
                        label="감지할 스킬"
                    )
                with gr.Column(scale=1):
                    sensitivity_input = gr.Slider(
                        minimum=3, maximum=60, value=15, step=1,
                        label="감도 (낮을수록 민감)"
                    )
                    auto_locate_input = gr.Checkbox(
                        value=True,
                        label="스킬바 위치 자동 탐지"
                    )

            analyze_btn = gr.Button("🔍 자동 분석 시작", variant="primary", size="lg")

            gr.Markdown("""
            💡 **사용 팁:**
            - YouTube 영상은 720p로 다운로드됩니다 (분석에 충분)
            - 감도 15가 기본값. 너무 많이 감지되면 ↑, 너무 적으면 ↓
            - 알비온이 아닌 영상이면 "자동 탐지" 해제 후 직접 확인
            """)

        # ════════════════════════════════════════
        # STEP 2: 분석 결과
        # ════════════════════════════════════════
        with gr.Tab("2️⃣ 분석 결과"):
            with gr.Row():
                filter_radio = gr.Radio(
                    choices=[("전체", "all"), ("✅ 잘씀", "good"),
                             ("❌ 못씀", "bad"), ("⬜ 미판정", "neutral")],
                    value="all",
                    label="필터"
                )

            log_table = gr.Dataframe(
                headers=["판정", "스킬", "시간", "메모", "변화도", "idx"],
                datatype=["str", "str", "str", "str", "number", "number"],
                row_count=(0, "dynamic"),
                col_count=(6, "fixed"),
                interactive=False,
                wrap=True,
                label="📋 로그 (클릭하여 클립 보기)",
            )

            with gr.Row():
                gr.Markdown("**선택된 로그**:")
                selected_info = gr.Markdown("로그를 클릭하세요")

            with gr.Row():
                clip_player = gr.Video(
                    label="🎬 클립 (-5초 ~ +3초)",
                    interactive=False
                )

            with gr.Row():
                with gr.Column(scale=2):
                    note_input = gr.Textbox(
                        label="📝 메모",
                        placeholder="이 스킬 사용에 대한 메모...",
                        lines=2
                    )
                with gr.Column(scale=1):
                    eval_display = gr.Markdown("⬜ 미판정")
                    with gr.Row():
                        eval_good_btn = gr.Button("✅ 잘씀", variant="primary", size="sm")
                        eval_bad_btn = gr.Button("❌ 못씀", size="sm")
                        eval_clear_btn = gr.Button("⬜ 초기화", size="sm")

        # ════════════════════════════════════════
        # STEP 3: 통계 & 내보내기
        # ════════════════════════════════════════
        with gr.Tab("3️⃣ 통계 & 데이터"):
            stats_md = gr.Markdown("**아직 분석 결과가 없습니다**")

            gr.Markdown("### 💾 내보내기")
            with gr.Row():
                export_csv_btn = gr.Button("📊 CSV 내보내기")
                export_json_btn = gr.Button("📄 JSON 내보내기")

            csv_file = gr.File(label="CSV 다운로드", visible=False, interactive=False)
            json_file = gr.File(label="JSON 다운로드", visible=False, interactive=False)

            gr.Markdown("### 📂 불러오기")
            import_json_file = gr.File(
                label="JSON 파일 (이어서 작업)",
                file_types=[".json"],
                type="filepath"
            )

            gr.Markdown("### ⚠️ 위험 영역")
            clear_btn = gr.Button("🗑 모든 로그 초기화", variant="stop")

        # ════════════════════════════════════════
        # EVENT WIRING
        # ════════════════════════════════════════

        # YouTube 다운로드
        yt_load_btn.click(
            fn=handle_youtube_load,
            inputs=[yt_url],
            outputs=[video_path_state, video_preview, status_display]
        )

        # 파일 업로드
        file_upload.change(
            fn=handle_file_upload,
            inputs=[file_upload],
            outputs=[video_path_state, video_preview, status_display]
        )

        # 분석 실행
        analyze_btn.click(
            fn=handle_analyze,
            inputs=[video_path_state, skills_input, sensitivity_input,
                    auto_locate_input, events_state],
            outputs=[events_state, log_table, stats_md, status_display]
        )

        # 필터
        filter_radio.change(
            fn=handle_filter,
            inputs=[events_state, filter_radio],
            outputs=[log_table]
        )

        # 로그 행 선택 → 클립 표시
        def on_select(evt: gr.SelectData, video_path, events):
            if evt is None or evt.index is None:
                return None, None, "로그를 클릭하세요", "", "⬜ 미판정"
            row_idx = evt.index[0] if isinstance(evt.index, list) else evt.index
            clip, info, note, eval_text = handle_play_clip(video_path, events, row_idx)
            return row_idx, clip, info, note, eval_text

        log_table.select(
            fn=on_select,
            inputs=[video_path_state, events_state],
            outputs=[selected_row_state, clip_player, selected_info, note_input, eval_display]
        )

        # 판정 버튼
        eval_good_btn.click(
            fn=lambda evs, idx: handle_set_eval(evs, idx, True),
            inputs=[events_state, selected_row_state],
            outputs=[events_state, log_table, stats_md]
        )
        eval_bad_btn.click(
            fn=lambda evs, idx: handle_set_eval(evs, idx, False),
            inputs=[events_state, selected_row_state],
            outputs=[events_state, log_table, stats_md]
        )
        eval_clear_btn.click(
            fn=lambda evs, idx: handle_set_eval(evs, idx, None),
            inputs=[events_state, selected_row_state],
            outputs=[events_state, log_table, stats_md]
        )

        # 메모 업데이트 (blur 시)
        note_input.blur(
            fn=handle_update_note,
            inputs=[events_state, selected_row_state, note_input],
            outputs=[events_state, log_table]
        )

        # CSV / JSON 내보내기
        export_csv_btn.click(
            fn=handle_export_csv,
            inputs=[events_state],
            outputs=[csv_file]
        ).then(
            lambda f: gr.update(visible=bool(f), value=f),
            inputs=[csv_file],
            outputs=[csv_file]
        )

        export_json_btn.click(
            fn=handle_export_json,
            inputs=[events_state, video_path_state],
            outputs=[json_file]
        ).then(
            lambda f: gr.update(visible=bool(f), value=f),
            inputs=[json_file],
            outputs=[json_file]
        )

        # JSON 불러오기
        import_json_file.change(
            fn=handle_import_json,
            inputs=[import_json_file, events_state],
            outputs=[events_state, log_table, stats_md, status_display]
        )

        # 초기화
        clear_btn.click(
            fn=handle_clear_logs,
            outputs=[events_state, log_table, stats_md, status_display]
        )

    return app


# ─────────────────────────────────────────
# ENTRY POINT
# ─────────────────────────────────────────
if __name__ == "__main__":
    app = build_ui()
    app.launch(
        server_name="0.0.0.0",       # 외부 접근 허용
        server_port=7860,            # HF Spaces 기본 포트
        share=False,                  # 로컬: False / 외부 공유 시 True
        show_error=True,
    )
