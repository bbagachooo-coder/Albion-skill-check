# 🚀 배포 가이드

이 가이드는 Albion VOD Analyzer를 **Hugging Face Spaces에 무료로 배포**하는 방법을 안내합니다.

소요 시간: **약 10분**

---

## 📋 준비물

1. **GitHub 계정** (https://github.com)
2. **Hugging Face 계정** (https://huggingface.co)
3. **Git** 설치 (https://git-scm.com)

---

## 1️⃣ GitHub에 코드 업로드

### A. GitHub에서 새 저장소 생성

1. https://github.com/new 접속
2. Repository name: `albion-vod-analyzer` (또는 원하는 이름)
3. Public 선택
4. **Create repository** 클릭

### B. 로컬에서 코드 푸시

터미널/Powershell에서:

```bash
# 프로젝트 폴더로 이동
cd 알비온-vod-analyzer-폴더

# Git 초기화
git init
git branch -M main
git add .
git commit -m "Initial commit: Albion VOD Analyzer"

# GitHub에 연결 (YOUR_USERNAME 본인 것으로 변경)
git remote add origin https://github.com/YOUR_USERNAME/albion-vod-analyzer.git
git push -u origin main
```

GitHub 페이지 새로고침하면 파일들이 보여야 합니다.

---

## 2️⃣ Hugging Face Space 생성

### A. Space 만들기

1. https://huggingface.co/new-space 접속
2. 다음과 같이 입력:

   | 항목 | 값 |
   |------|-----|
   | Owner | 본인 계정 |
   | Space name | `albion-vod-analyzer` |
   | License | MIT |
   | SDK | **Gradio** ⚠️ |
   | Hardware | **CPU basic · FREE** ⚠️ |
   | Public 또는 Private | Public (무료 사용 시) |

3. **Create Space** 클릭

### B. 코드 업로드 (3가지 방법 중 택 1)

#### 방법 1: GitHub에서 파일 복사 (가장 쉬움)

1. Space 페이지에서 **Files** 탭 클릭
2. **Add file → Upload files** 클릭
3. 로컬 폴더에서 `app.py`, `requirements.txt`, `README.md` 드래그
4. **Commit** 클릭

#### 방법 2: Git으로 직접 푸시 (개발자용)

```bash
# HF Space를 git remote로 추가
git remote add space https://huggingface.co/spaces/YOUR_HF_USERNAME/albion-vod-analyzer

# 푸시
git push space main
```

이때 HF 토큰 입력 필요 (https://huggingface.co/settings/tokens 에서 발급)

#### 방법 3: GitHub 자동 동기화 (추천)

1. Space의 **Settings** → **Sync with GitHub** 클릭
2. GitHub 저장소 URL 입력
3. 이후 GitHub에 푸시하면 자동으로 HF Space도 업데이트됨

---

## 3️⃣ 빌드 & 테스트

1. Space 페이지의 **Logs** 탭에서 빌드 진행 확인
2. 처음 빌드는 **2~5분** 소요 (패키지 설치)
3. 빌드 완료 후 **App** 탭에서 동작 확인

빌드 실패 시:
- `requirements.txt` 버전 확인
- Logs에서 에러 메시지 확인
- 패키지 버전을 살짝 낮춰서 재시도

---

## 4️⃣ 모바일에서 접속

배포 완료되면 다음 URL로 어디서든 접속 가능:

```
https://YOUR_HF_USERNAME-albion-vod-analyzer.hf.space
```

또는

```
https://huggingface.co/spaces/YOUR_HF_USERNAME/albion-vod-analyzer
```

- 폰 브라우저에서 그대로 사용 가능
- 모바일 반응형 UI 자동 적용
- 홈 화면에 추가하면 앱처럼 사용 가능 (PWA)

---

## ⚙️ PC에서 개발 이어가기

```bash
# 1. 저장소 클론
git clone https://github.com/YOUR_USERNAME/albion-vod-analyzer.git
cd albion-vod-analyzer

# 2. 가상환경 생성 (선택)
python -m venv venv
source venv/bin/activate  # Mac/Linux
# venv\Scripts\activate  # Windows

# 3. 패키지 설치
pip install -r requirements.txt

# 4. 실행
python app.py
```

브라우저에서 http://localhost:7860 접속

### 코드 수정 후 배포 반영

```bash
git add .
git commit -m "Update: 변경 내용 설명"
git push origin main
# GitHub 자동 동기화 설정한 경우 HF Space도 자동 업데이트됨
```

---

## 🔧 트러블슈팅

### "Build failed" 에러

**원인**: 패키지 버전 충돌
**해결**:
```
# requirements.txt를 다음으로 변경
gradio
yt-dlp
opencv-python-headless
numpy
```
버전을 빼면 최신 버전 자동 설치됨

### "Sleeping" 상태

- 무료 CPU Space는 일정 시간 미사용 시 sleep
- 다시 접속하면 자동으로 깨어남 (30초~1분 대기)
- 이는 정상이며 무료 정책상 어쩔 수 없음

### YouTube 다운로드 실패

- HF Space에서 일부 YouTube 영상은 차단될 수 있음
- 이 경우 로컬에서 다운로드한 파일을 업로드하는 방식 사용
- 또는 yt-dlp를 업데이트: `requirements.txt`에서 `yt-dlp>=2024.x.x` 명시

### 분석이 너무 느림

- 무료 CPU의 한계
- 짧은 클립(5~10분)으로 테스트 권장
- 본격 분석은 로컬 PC에서 실행 추천

---

## 📈 다음 단계

배포 완료 후 가능한 개선:

1. **GitHub Actions로 자동 배포**: PR 머지 시 자동 동기화
2. **유료 GPU 업그레이드**: 분석 속도 10배 빨라짐 ($0.40/시간)
3. **Docker 배포**: Railway, Render 등 다른 플랫폼
4. **PWA 변환**: 모바일 앱처럼 설치 가능하게

---

## 💡 추가 팁

- HF Space URL을 친구에게 공유하면 누구나 사용 가능
- 통계, 사용 기록은 클라우드에 저장되지 않음 (다운로드 권장)
- 본격적인 분석은 로컬 PC에서 실행이 더 빠르고 안정적

---

배포 중 문제가 생기면 HF Spaces 공식 문서 참고:
https://huggingface.co/docs/hub/spaces
