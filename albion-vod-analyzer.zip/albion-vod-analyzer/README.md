---
title: Albion VOD Analyzer
emoji: ⚔️
colorFrom: yellow
colorTo: red
sdk: gradio
sdk_version: 4.44.0
app_file: app.py
pinned: false
license: mit
short_description: Auto-detect skill usage in Albion Online PvP videos
---

# ⚔️ Albion VOD Analyzer

알비온 온라인 PvP 영상에서 스킬 사용 타이밍을 **자동으로 감지**하고 기록·분석하는 웹 앱입니다.

🌐 **온라인 사용**: 위 Space에서 바로 사용 가능 (모바일도 지원)
💻 **로컬 실행**: 아래 설치 가이드 참고

## ✨ 주요 기능

- 📺 **YouTube URL 입력 → 자동 다운로드 → 자동 분석** (원클릭)
- 📁 로컬 mp4 / webm / mov 파일 직접 업로드
- 🔍 9개 스킬 슬롯 (A/Q/W/E/R/D/F/1/2) **개별 식별**
- 🎯 HSV 채도 변화 기반 픽셀 분석 (알비온 UI 최적화)
- 🎬 로그 클릭 시 **-5초 ~ +3초 클립** 자동 추출 & 재생
- ✅❌ 잘 씀 / 못 씀 / 메모 수동 판정
- 📊 스킬별 정확도 통계
- 💾 CSV / JSON 내보내기
- 📂 JSON 불러와서 이어서 작업

## 🚀 사용법

### 온라인 (Hugging Face Spaces)

1. 위 Space 페이지 접속
2. **1️⃣ 영상 로드 & 분석** 탭에서 YouTube URL 입력 or 파일 업로드
3. 감지할 스킬 선택 → **🔍 자동 분석 시작**
4. **2️⃣ 분석 결과** 탭에서 로그 클릭 → 클립 보고 판정
5. **3️⃣ 통계 & 데이터** 탭에서 CSV/JSON 저장

### 로컬 실행 (개발 / 무제한 사용)

```bash
# 1. 프로젝트 클론
git clone https://github.com/YOUR_USERNAME/albion-vod-analyzer.git
cd albion-vod-analyzer

# 2. 패키지 설치
pip install -r requirements.txt

# 3. 실행
python app.py

# 브라우저에서 http://localhost:7860 접속
```

같은 와이파이의 모바일 기기에서도 접속 가능:
- PC IP 확인 후 `http://<PC-IP>:7860` 으로 접속

## 🧠 감지 알고리즘

알비온 스킬바의 시각적 특성을 활용합니다:

| 상태 | 시각적 특성 | HSV 채도 |
|------|------------|---------|
| 사용 가능 | 컬러풀한 아이콘 | 높음 |
| 쿨타임 중 | 회색 숫자 | 낮음 |

0.25초마다 프레임을 캡처해서 9개 슬롯 각각의 채도를 추적. 채도가 **급격히 떨어지는 순간**을 스킬 사용으로 판단합니다.

### 감도 조절

- **3~10**: 매우 민감 (오탐 많음, 추천 ❌)
- **15** (기본): 균형 (대부분 잘 작동)
- **20~30**: 보수적 (확실한 변화만)
- **40~60**: 매우 보수적 (놓치는 경우 많음)

### 스킬바 위치 자동 탐지

ON (기본): 영상마다 다른 해상도/UI 배치에 자동 적응
OFF: 하단 10~12% 영역을 스킬바로 가정 (표준 알비온 영상에만)

## 📦 기술 스택

- **Gradio 4** — 웹 UI 프레임워크
- **yt-dlp** — YouTube 다운로드
- **OpenCV (headless)** — 영상 프레임 처리
- **NumPy** — 픽셀 분석

## 🛠 개발

### 프로젝트 구조

```
albion-vod-analyzer/
├── app.py              # 메인 Gradio 앱
├── requirements.txt    # Python 패키지
├── README.md          # 이 파일 (HF Spaces 메타데이터 포함)
└── .gitignore         # Git 제외 항목
```

### 코드 흐름

1. `download_youtube()` — yt-dlp로 영상 다운로드
2. `locate_skill_bar()` — 스킬바 Y 좌표 자동 탐지
3. `analyze_video()` — 프레임별 채도 변화 분석 → 이벤트 추출
4. `extract_clip()` — 특정 시점 클립 mp4 생성
5. `build_ui()` — Gradio UI 구성

### HF Spaces 배포

이 저장소를 GitHub에 푸시한 뒤:

1. https://huggingface.co/new-space 접속
2. SDK: **Gradio** 선택
3. Hardware: **CPU basic** (무료) 선택
4. "Link from GitHub" 또는 직접 파일 업로드
5. 자동 빌드 후 1~2분 내 활성화

## ⚠️ 제약사항

### Hugging Face Spaces (CPU 무료)

- 첫 접속 시 sleep 모드 → 깨어나는데 30초 ~ 1분
- 동시 사용자 많으면 분석 속도 저하
- 큰 영상(1시간+)은 무료 CPU로 5~10분 소요
- 일시 파일은 컨테이너 재시작 시 삭제됨

### 로컬 실행 (추천)

위 제약 모두 없음. PC 사양에 따라 빠르게 분석 가능.

## 📝 라이선스

MIT License — 자유롭게 사용/수정/배포 가능

## 🤝 기여

이슈 / PR 환영합니다!

---

⭐ **사용해보고 마음에 들면 Like 눌러주세요!**
